#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>



#define NUM_BLOCKS 9
#define PIPE_WRITE 1

typedef struct {
  int board[3][3];
  int original[3][3];
  int read_pipes[4];  // pipes for reading from neighbors
  int write_pipes[4]; // pipes for writing to neighbors
} BlockState;

BlockState blocks[NUM_BLOCKS];
pid_t block_pids[NUM_BLOCKS];

void newboard ( int A[9][9], int S[9][9] )
{
   int P[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }, *Q, i, j, k, r, s, t;

   int B[9][9] = { {1, 0, 0, 0, 0, 8, 0, 0, 9},
                   {0, 0, 2, 0, 0, 0, 0, 0, 8},
                   {0, 8, 0, 5, 4, 9, 0, 0, 0},
                   {0, 4, 0, 2, 0, 0, 9, 0, 0},
                   {3, 0, 9, 0, 0, 0, 2, 0, 1},
                   {0, 0, 1, 0, 0, 5, 0, 4, 0},
                   {0, 0, 0, 9, 1, 2, 0, 3, 0},
                   {7, 0, 0, 0, 0, 0, 1, 0, 0},
                   {2, 0, 0, 7, 0, 0, 0, 0, 6}
                 },
       C[9][9] = { {1, 3, 4, 6, 2, 8, 5, 7, 9},
                   {9, 5, 2, 1, 3, 7, 4, 6, 8},
                   {6, 8, 7, 5, 4, 9, 3, 1, 2},
                   {5, 4, 6, 2, 7, 1, 9, 8, 3},
                   {3, 7, 9, 4, 8, 6, 2, 5, 1},
                   {8, 2, 1, 3, 9, 5, 6, 4, 7},
                   {4, 6, 8, 9, 1, 2, 7, 3, 5},
                   {7, 9, 5, 8, 6, 3, 1, 2, 4},
                   {2, 1, 3, 7, 5, 4, 8, 9, 6}
                 };

   srand((unsigned int)time(NULL));
   Q = P + 1;
   for (i=8; i>0; --i) {
      j = rand() % (i + 1);
      t = Q[i]; Q[i] = Q[j]; Q[j] = t;
   }
   for (k=0; k<9; k+=3) {
      s = rand() % 3;
      t = rand() % 3;
      if (s != t) {
         for (j=0; j<9; ++j) {
            r = B[k+s][j]; B[k+s][j] = B[k+t][j]; B[k+t][j] = r;
            r = C[k+s][j]; C[k+s][j] = C[k+t][j]; C[k+t][j] = r;
         }
      }
   }
   for (k=0; k<9; k+=3) {
      s = rand() % 3;
      t = rand() % 3;
      if (s != t) {
         for (i=0; i<9; ++i) {
            r = B[i][k+s]; B[i][k+s] = B[i][k+t]; B[i][k+t] = r;
            r = C[i][k+s]; C[i][k+s] = C[i][k+t]; C[i][k+t] = r;
         }
      }
   }
   if (rand()%2) {
      for (i=0; i<9; ++i) {
         for (j=0; j<9; ++j) {
            A[i][j] = P[B[i][j]];
            S[i][j] = P[C[i][j]];
         }
      }
   } else {
      for (i=0; i<9; ++i) {
         for (j=0; j<9; ++j) {
            A[i][j] = P[B[j][i]];
            S[i][j] = P[C[j][i]];
         }
      }
   }
}

void print_help() {
  printf("\nFoodoku Game Commands:\n");
  printf("h - Help\n");
  printf("n - New game\n");
  printf("p b c d - Place digit d at cell c of block b\n");
  printf("s - Show S\n");
  printf("q - Quit\n");
}

int check_block_conflict(int block, int digit) {
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < 3; c++) {
      if (blocks[block].board[r][c] == digit)
        return 1;
    }
  }
  return 0;
}

int check_row_conflict(int block, int row, int digit) {
  for (int c = 0; c < 3; c++) {
    if (blocks[block].board[row][c] == digit)
      return 1;
  }
  return 0;
}

int check_col_conflict(int block, int col, int digit) {
  for (int r = 0; r < 3; r++) {
    if (blocks[block].board[r][col] == digit)
      return 1;
  }
  return 0;
}

int validate_move(int block, int cell, int digit) {
  int row = cell / 3;
  int col = cell % 3;

  // Check if cell is read-only
  if (blocks[block].original[row][col] != 0)
    return 0;

  // Check block conflict
  if (check_block_conflict(block, digit))
    return 0;

  // Simulate row and column conflict checks
  // Identify neighboring blocks
  int row_blocks[2], col_blocks[2];
  int block_row = block / 3;
  int block_col = block % 3;

  row_blocks[0] = (block_row * 3) + ((block_col + 1) % 3);
  row_blocks[1] = (block_row * 3) + ((block_col + 2) % 3);

  col_blocks[0] = ((block_row + 1) % 3) * 3 + block_col;
  col_blocks[1] = ((block_row + 2) % 3) * 3 + block_col;

  // Perform row conflict check
  for (int i = 0; i < 2; i++) {
    if (check_row_conflict(row_blocks[i], row, digit))
      return 0;
  }

  // Perform column conflict check
  for (int i = 0; i < 2; i++) {
    if (check_col_conflict(col_blocks[i], col, digit))
      return 0;
  }

  return 1;
}

int main() {
  int A[9][9], S[9][9];
  int pipes[NUM_BLOCKS][2][2];

  // Pipe setup
  for (int i = 0; i < NUM_BLOCKS; i++) {
    if (pipe(pipes[i][0]) == -1 || pipe(pipes[i][1]) == -1) {
      perror("Pipe creation failed");
      exit(1);
    }
  }

  // Fork block processes
  for (int i = 0; i < NUM_BLOCKS; i++) {
    block_pids[i] = fork();
    if (block_pids[i] == 0) {
      // Block process
      char block_str[10], bfdin_str[10], bfdout_str[10], rn1_str[10],
          rn2_str[10], cn1_str[10], cn2_str[10];

      sprintf(block_str, "%d", i);
      sprintf(bfdin_str, "%d", pipes[i][0][0]);
      sprintf(bfdout_str, "%d", pipes[i][1][1]);

      // Determine neighboring block pipes
      int row_neighbors[2], col_neighbors[2];
      int block_row = i / 3;
      int block_col = i % 3;

      row_neighbors[0] = (block_row * 3) + ((block_col + 1) % 3);
      row_neighbors[1] = (block_row * 3) + ((block_col + 2) % 3);

      col_neighbors[0] = ((block_row + 1) % 3) * 3 + block_col;
      col_neighbors[1] = ((block_row + 2) % 3) * 3 + block_col;

      sprintf(rn1_str, "%d", pipes[row_neighbors[0]][1][1]);
      sprintf(rn2_str, "%d", pipes[row_neighbors[1]][1][1]);
      sprintf(cn1_str, "%d", pipes[col_neighbors[0]][1][1]);
      sprintf(cn2_str, "%d", pipes[col_neighbors[1]][1][1]);

      execl("/usr/bin/xterm", "xterm", "-T", block_str, "-fa", "Monospace",
            "-fs", "15", "-geometry", "17x8+800+300", "-e", "./block",
            block_str, bfdin_str, bfdout_str, rn1_str, rn2_str, cn1_str,
            cn2_str, NULL);

      perror("Exec failed");
      exit(1);
    }
  }

  // Coordinator process
  char command[100];
  int game_active = 0;

  while (1) {
    printf("Enter command (h for help): ");
    fgets(command, sizeof(command), stdin);
    command[strcspn(command, "\n")] = 0;

    switch (command[0]) {
    case 'h':
      print_help();
      break;
      // Modify the 'n' case in the switch statement
case 'n':
    newboard(A, S);
    for (int i = 0; i < NUM_BLOCKS; i++) {
        dprintf(blocks[i].write_pipes[PIPE_WRITE], "n ");
        int row_start = (i / 3) * 3;
        int col_start = (i % 3) * 3;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                dprintf(blocks[i].write_pipes[PIPE_WRITE], "%d ", 
                    A[row_start + r][col_start + c]);
            }
        }
        dprintf(blocks[i].write_pipes[PIPE_WRITE], "\n");
    }
    break;

case 'p':
    int b,c,d;
    scanf("%d %d %d", &b, &c, &d);
    if (b < 0 || b >= 9 || c < 0 || c >= 9 || d < 1 || d > 9) {
        printf("Invalid input ranges\n");
    } else {
        dprintf(blocks[b].write_pipes[PIPE_WRITE], "p %d %d\n", c, d);
    }
    break;


case 's':
    if (!game_active) {
        printf("Start a new game first (command 'n')\n");
        break;
    }

    // Send S to all blocks
    for (int i = 0; i < NUM_BLOCKS; i++) {
        char S_data[100];
        snprintf(S_data, sizeof(S_data), "n %d %d %d %d %d %d %d %d %d", 
            S[(i/3)*3][((i%3)*3)],
            S[(i/3)*3][((i%3)*3)+1],
            S[(i/3)*3][((i%3)*3)+2],
            S[(i/3)*3+1][((i%3)*3)],
            S[(i/3)*3+1][((i%3)*3)+1],
            S[(i/3)*3+1][((i%3)*3)+2],
            S[(i/3)*3+2][((i%3)*3)],
            S[(i/3)*3+2][((i%3)*3)+1],
            S[(i/3)*3+2][((i%3)*3)+2]
        );

        // Send S data to this block's write pipe
        write(pipes[i][1][1], S_data, strlen(S_data));

        // Update local block state
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                blocks[i].board[r][c] = S[(i/3)*3 + r][(i%3)*3 + c];
            }
        }
    }
    printf("S displayed\n");
    break;
    case 'q':
      for (int i = 0; i < NUM_BLOCKS; i++) {
        kill(block_pids[i], SIGTERM);
        waitpid(block_pids[i], NULL, 0);
      }
      exit(0);
    default:
      printf("Invalid command. Use 'h' for help.\n");
    }
  }

  return 0;
}