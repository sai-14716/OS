#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <string.h>

#define max_child_length 100
#define CATCH_PROBABILITY 0.8

int my_index;
int no_of_children;

pid_t child_pids[max_child_length];

int my_status_bool = 1; 

char status_of_child[10] = "....";

void print_status() 
{
    printf("|");
    for (int i = 0; i < no_of_children; i++) 
    {
        
        if (i > 0) printf(" ");
        
        if (i + 1 == my_index) 
        {
            printf("%-4s", status_of_child);
        } 
        
        else 
        {
            printf("    ");
        }
    }
    
    printf(" |\n");
    
    printf("+----------------------------------------------------------------------------------------+\n");
    
    fflush(stdout);
}

void handle_sigusr1(int signum) 
{
    // Signal to print status
    print_status();
    
    if (my_index < no_of_children) 
    {
        // Forward the print signal to next child
        kill(child_pids[my_index], SIGUSR1);
    } 
    else 
    {
        // Last child signals dummy to exit
        FILE *dummy_db = fopen("dummycpid.txt", "r");
        pid_t dummy_pid;
        fscanf(dummy_db, "%d", &dummy_pid);
        fclose(dummy_db);
        kill(dummy_pid, SIGINT);
    }
}

void handle_sigusr2(int signum) 
{
    // Ball thrown to this child
    double catch_chance = (double)rand() / RAND_MAX;
    pid_t parent_pid = getppid();
    
    if (catch_chance < CATCH_PROBABILITY) 
    {
        // Caught the ball
        strcpy(status_of_child, "CATCH");
        kill(parent_pid, SIGUSR1);
    } 
    else 
    {
        // Missed the ball
        strcpy(status_of_child, "MISS");
        kill(parent_pid, SIGUSR2);
       my_status_bool = 0;
        strcpy(status_of_child, "    ");
    }
}

void handle_sigint(int signum) 
{
    if (my_status_bool) 
    {
        printf("+++ Child %d: Yay! I am the winner!\n", my_index);
        fflush(stdout);
    }

    exit(0);
}

int main(int argc, char *argv[])
{
    if (argc != 2) 
    {
        fprintf(stderr, "Usage: %s <index>\n", argv[0]);
        exit(1);
    }

    my_index = atoi(argv[1]);
    srand(time(NULL) ^ (getpid() << 16));

    // Set up signal handlers
    
    signal(SIGUSR1, handle_sigusr1);
    signal(SIGUSR2, handle_sigusr2);
    signal(SIGINT, handle_sigint);

    // Wait for parent to write child database
    sleep(1);

    // Read child database

    FILE *child_db = fopen("childpid.txt", "r");
    fscanf(child_db, "%d", &no_of_children);

    for (int i = 0; i < no_of_children; i++) 
    {
        fscanf(child_db, "%d", &child_pids[i]);
    }

    fclose(child_db);

    // Enter infinite loop waiting for signals
    while (1) 
    {
        pause();
    }

    return 0;
}