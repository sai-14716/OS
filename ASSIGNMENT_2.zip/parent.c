#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

#define max_child_length 100

pid_t child_pids[max_child_length];
int no_of_children;


int catch_status[max_child_length]; 
int last_throw = -1;
int players_remaining;


//Creating the functions for handling the signals
void handle_sigusr1(int signum) 
{
    // catches
    catch_status[last_throw] = 1;
}

void handle_sigusr2(int signum) 
{
    // misses
    catch_status[last_throw] = 0;
    players_remaining--;
}



int next_player(int current) 
{
    int next = (current + 1) % no_of_children;
    
    while (!catch_status[next] && players_remaining > 1) 
    {
        next = (next + 1) % no_of_children;
    }
    
    return next;
}

int main(int argc, char *argv[]) 
{
    if (argc != 2) 
    {
        fprintf(stderr, "NO NUMBER ENTERED\n", argv[0]);
        exit(1);
    }

    no_of_children = atoi(argv[1]);

    if (no_of_children <= 0 || no_of_children > max_child_length) 
    {
        fprintf(stderr, "Numbver is out of limits", max_child_length);
        exit(1);
    }

  
    signal(SIGUSR1, handle_sigusr1);
    signal(SIGUSR2, handle_sigusr2);

    // Creating child processes
    FILE *child_db = fopen("childpid.txt", "w");
    fprintf(child_db, "%d\n", no_of_children);
    
    for (int i = 0; i < no_of_children; i++) 
    {
        pid_t pid = fork();

        if (pid < 0) 
        {
            perror("Fork failed");
            exit(1);
        } 
        else if (pid == 0) 
        {
            // Child process
            char index_str[10];
            sprintf(index_str, "%d", i + 1);
            execl("./child", "child", index_str, NULL);
            perror("Exec failed");
            exit(1);
        }

        child_pids[i] = pid;
        catch_status[i] = 1;
        fprintf(child_db, "%d\n", pid);
    }

    fclose(child_db);

    players_remaining = no_of_children;
    printf("Parent: %d child processes created\n", no_of_children);
    printf("Parent: Waiting for child processes to read child database\n");
    
    //player numbers
    for (int i = 1; i <= no_of_children; i++) 
    {
        printf("%d ", i);
    }
    printf("\n");

    sleep(2);  

    // Game loop
    while (players_remaining > 1) 
    {
        last_throw = next_player(last_throw);
        
        // Create dummy process for synchronization
        pid_t dummy_pid = fork();
        
        if (dummy_pid == 0) 
        {
            execl("./dummy", "dummy", NULL);
            perror("Exec dummy failed");
            exit(1);
        }

        // Write dummy pid to file
        FILE *dummy_db = fopen("dummycpid.txt", "w");
        fprintf(dummy_db, "%d\n", dummy_pid);
        fclose(dummy_db);

        // Send ball to next player
        kill(child_pids[last_throw], SIGUSR2);
        
        // Wait for response (handled by signal handlers)
        pause();

        // Start status printing
        kill(child_pids[0], SIGUSR1);
        
        // Wait for dummy to be killed
        waitpid(dummy_pid, NULL, 0);
    }

    // sneding sigint to child 
    for (int i = 0; i < no_of_children; i++) 
    {
        kill(child_pids[i], SIGINT);
    }

    // Wait for all children to exit
    while (wait(NULL) > 0);

    return 0;
}