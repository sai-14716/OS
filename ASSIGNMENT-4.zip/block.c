#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

void draw_block(int block_number, int block[3][3]) {
    fprintf(stdout, "\033[2J\033[H");  // Clear screen
    printf("Block %d\n", block_number);
    printf("+---+---+---+\n");
    
    for (int i = 0; i < 3; i++) {
        printf("|");
        for (int j = 0; j < 3; j++) {
            if (block[i][j] == 0)
                printf(" . ");
            else
                printf(" %d ", block[i][j]);
            printf("|");
        }
        printf("\n+---+---+---+\n");
    }
    fflush(stdout);
}

int main(int argc, char *argv[]) {
    if (argc < 8) {
        fprintf(stderr, "Insufficient arguments\n");
        return 1;
    }

    int block_number = atoi(argv[1]);
    int bfdin = atoi(argv[2]);

    int A[3][3] = {0};  // Original puzzle block
    int B[3][3] = {0};  // Current state block

    // Redirect stdin to pipe
    dup2(bfdin, STDIN_FILENO);
    
    draw_block(block_number, B);  // Initial draw

    char command;
    int cell, digit, row, col;
    
    while (1) {
        scanf(" %c", &command);
        
        switch (command) {
            case 'n':
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        scanf("%d", &A[i][j]);
                        B[i][j] = A[i][j];
                    }
                }
                draw_block(block_number, B);
                break;
                
            case 'p':
                scanf("%d %d", &cell, &digit);
                row = cell / 3;
                col = cell % 3;
                B[row][col] = digit;
                draw_block(block_number, B);
                break;
                
            case 'q':
                printf("Bye...\n");
                sleep(2);
                exit(0);
        }
    }
    return 0;
}